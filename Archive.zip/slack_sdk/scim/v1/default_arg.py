class DefaultArg:
    pass


NotGiven = DefaultArg()
